```json vega
{
  "$schema": "https://vega.github.io/schema/vega/v5.json",
  "description": "This is the central brain of the page",
  "signals": [
    {
      "name": "selectedGenre",
      "value": ""
    },
    {
      "name": "filteredByGenre",
      "update": "data('filteredByGenre')"
    },
    {
      "name": "selectedCreativeType",
      "value": ""
    },
    {
      "name": "selectedMpaaRating",
      "value": ""
    },
    {
      "name": "selected_Major_Genre",
      "value": "All Movies",
      "update": "selectedGenre && selectedGenre !== 'null' && selectedGenre !== '' ? selectedGenre + ' Movies' : 'All Movies'"
    },
    {
      "name": "filteredByCreativeType",
      "update": "data('filteredByCreativeType')"
    },
    {
      "name": "selected_Creative_Type",
      "value": "All Creative Types",
      "update": "selectedCreativeType && selectedCreativeType !== 'null' && selectedCreativeType !== '' ? selectedCreativeType + ' Movies' : 'All Creative Types'"
    },
    {
      "name": "selected_MPAA_Rating",
      "value": "All Ratings",
      "update": "selectedMpaaRating && selectedMpaaRating !== 'null' && selectedMpaaRating !== '' ? selectedMpaaRating + ' Movies' : 'All Ratings'"
    },
    {
      "name": "filteredByMpaaRating",
      "update": "data('filteredByMpaaRating')"
    },
    {
      "name": "moviesData",
      "update": "data('moviesData')"
    }
  ],
  "data": [
    {
      "name": "moviesData",
      "url": "https://vega.github.io/editor/data/movies.json",
      "format": {
        "type": "json"
      }
    },
    {
      "name": "filteredByGenre",
      "source": [
        "moviesData"
      ],
      "transform": [
        {
          "type": "filter",
          "expr": "!selectedGenre || selectedGenre === '' || selectedGenre === 'null' || datum['Major Genre'] === selectedGenre"
        }
      ]
    },
    {
      "name": "filteredByCreativeType",
      "source": [
        "filteredByGenre"
      ],
      "transform": [
        {
          "type": "filter",
          "expr": "!selectedCreativeType || selectedCreativeType === '' || selectedCreativeType === 'null' || datum['Creative Type'] === selectedCreativeType"
        }
      ]
    },
    {
      "name": "filteredByMpaaRating",
      "source": [
        "filteredByCreativeType"
      ],
      "transform": [
        {
          "type": "filter",
          "expr": "!selectedMpaaRating || selectedMpaaRating === '' || selectedMpaaRating === 'null' || datum['MPAA Rating'] === selectedMpaaRating"
        },
        {
          "type": "collect",
          "sort": {
            "field": "IMDB Rating",
            "order": "descending"
          }
        },
        {
          "type": "window",
          "ops": [
            "rank"
          ],
          "as": [
            "Rank"
          ]
        },
        {
          "type": "filter",
          "expr": "datum.Rank <= 10"
        },
        {
          "type": "formula",
          "as": "ImdbUrl",
          "expr": "'https://www.imdb.com/find/?q=' + encodeURIComponent(datum['Title'])"
        }
      ]
    }
  ]
}
```


```css
html, body { height: 100%; margin: 0; padding: 0; scroll-behavior: smooth; overflow-y: auto; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
body { scroll-snap-type: y mandatory; }
.group { scroll-snap-align: start; min-height: 100vh; margin: 0; padding: 3em 2em; box-sizing: border-box; display: flex; flex-direction: column; justify-content: center; overflow: hidden; text-align: center; }
#intro { background: linear-gradient(135deg, #2c3e50 0%, #8b0000 100%); color: white; }
#genreFilter { background: linear-gradient(135deg, #8b0000 0%, #4b0082 100%); color: white; }
#creativeTypeFilter { background: linear-gradient(135deg, #4b0082 0%, #2c3e50 100%); color: white; }
#mpaaRatingFilter { background: linear-gradient(135deg, #2c3e50 0%, #1a1a2e 100%); color: white; }
#results { background: linear-gradient(135deg, #1a1a2e 0%, #8b0000 100%); color: white; text-align: left; }
h1 { font-size: 3em; margin: 0.3em 0; font-weight: 300; line-height: 1.2; text-shadow: 2px 2px 4px rgba(0,0,0,0.5); }
h2 { font-size: 2.2em; margin: 0.4em 0; font-weight: 300; line-height: 1.2; text-shadow: 1px 1px 3px rgba(0,0,0,0.5); }
h3 { font-size: 1.8em; margin: 0.5em 0; font-weight: 400; line-height: 1.2; }
p, label { font-size: 1.3em; line-height: 1.5; margin: 1em 0; }
.dropdown-container { margin: 2em 0; }
select { padding: 12px 20px; font-size: 1.1em; border-radius: 8px; border: none; background: rgba(255,255,255,0.9); color: #333; min-width: 250px; }
.movie-cards { display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 1.5em; padding: 2em 0; max-height: 600px; overflow-y: auto; }
.movie-card { background: linear-gradient(135deg, rgba(44,62,80,0.9) 0%, rgba(26,26,46,0.9) 100%); border: 2px solid rgba(139,0,0,0.5); border-radius: 12px; padding: 1.5em; box-shadow: 0 4px 12px rgba(0,0,0,0.5); transition: all 0.3s ease; text-decoration: none; color: unset;}
.movie-card:hover { transform: translateY(-5px); box-shadow: 0 8px 24px rgba(139,0,0,0.6); border-color: rgba(139,0,0,0.8); }
.movie-card h3 { margin: 0 0 0.5em 0; font-size: 1.4em; color: #fff; border-bottom: 2px solid rgba(139,0,0,0.5); padding-bottom: 0.5em; }
.movie-card p { margin: 0.5em 0; font-size: 1em; line-height: 1.4; }
.movie-card strong { color: rgba(255,255,255,0.8); }
.movie-card .rating { color: #ffd700; font-weight: bold; font-size: 1.1em; }
.results-header { background: rgba(139,0,0,0.8); padding: 20px; border-radius: 8px; margin-bottom: 20px; }
@media (max-width: 768px) { .group { padding: 2em 1em; } h1 { font-size: 2.2em; } h2 { font-size: 1.8em; } h3 { font-size: 1.4em; } p, label { font-size: 1.1em; } select { min-width: 200px; } .movie-cards { grid-template-columns: 1fr; } }
@media (max-width: 480px) { .group { padding: 1.5em 0.8em; } h1 { font-size: 1.8em; } h2 { font-size: 1.5em; } h3 { font-size: 1.2em; } p, label { font-size: 1em; } select { min-width: 180px; font-size: 1em; } }
```


::: group {#intro}

# 🎬 Movie Wizard
## Progressive Movie Explorer
### Discover your perfect movie through guided filtering

**Step through each screen to narrow down your movie selection**

🎭 *Welcome to the cinema experience*
:::
::: group {#genreFilter}

# 🎯 Step 1: Choose Your Genre
## What kind of story calls to you tonight?


```yaml dropdown
variableId: selectedGenre
value: ''
dynamicOptions:
  dataSourceName: moviesData
  fieldName: Major Genre
```


### {{selected_Major_Genre}}

**Scroll down to continue your journey →**
:::
::: group {#creativeTypeFilter}

# 🎨 Step 2: Creative Style
## How do you want your story told?


```yaml dropdown
variableId: selectedCreativeType
value: ''
dynamicOptions:
  dataSourceName: filteredByGenre
  fieldName: Creative Type
```


### {{selected_Creative_Type}}

**One more step to your perfect movie →**
:::
::: group {#mpaaRatingFilter}

# 🎟️ Step 3: Rating Preference
## What's appropriate for your audience?


```yaml dropdown
variableId: selectedMpaaRating
value: ''
dynamicOptions:
  dataSourceName: filteredByCreativeType
  fieldName: MPAA Rating
```


### {{selected_MPAA_Rating}}

**Ready to see your curated selection? →**
:::
::: group {#results}

# 🍿 Your Movie Selection

### {{selected_Major_Genre}} • {{selected_Creative_Type}} • {{selected_MPAA_Rating}}


```yaml treebark
template:
  div:
    class: movie-cards
    $bind: .
    $children:
      - a:
          href: '{{ImdbUrl}}'
          class: movie-card
          $children:
            - h3: 🎬 {{Title}}
            - p:
                $children:
                  - strong: 'Director: '
                  - '{{Director}}'
            - p:
                $children:
                  - strong: 'Release: '
                  - '{{Release Date}}'
            - p:
                $children:
                  - strong: 'Running Time: '
                  - '{{Running Time min}} min'
            - p:
                class: rating
                $children:
                  - '⭐ IMDB: {{IMDB Rating}}'
            - p:
                $children:
                  - strong: 'US Gross: '
                  - ${{US Gross}}
            - p:
                $children:
                  - strong: 'Worldwide: '
                  - ${{Worldwide Gross}}
variableId: filteredByMpaaRating
```


### 🎬 *Enjoy your movie night!*
:::